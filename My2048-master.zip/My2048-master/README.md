# My2048
<p> This is a web  2048 game</p>
<p>Gameplay: use up and down to control the game.</p>

UI show
![Image text](https://github.com/xiaobooo/img_buffer/blob/master/img/my2018.png)
